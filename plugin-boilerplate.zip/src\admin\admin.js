import './admin.scss';

console.log('admin.js');