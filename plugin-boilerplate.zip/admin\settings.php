<?php
namespace FFPlugin\PluginName;

vite_enqueue('admin', 'src/admin/admin.js');
?>

<h2>Plugin Settings</h2>